<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* base.html.twig */
class __TwigTemplate_704d5cd91301a7cf16bbfe154da1a2e513a5950ee7a55f49842876dc188ff566 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">

<head>
  <meta charset=\"utf-8\">
  <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
  <title>";
        // line 8
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
  <!-- Bootstrap core CSS -->
  <link rel=\"stylesheet\" href=\"https://ajax.aspnetcdn.com/ajax/bootstrap/4.3.1/css/bootstrap.min.css\">
  <link rel=\"stylesheet\" href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/styles.css"), "html", null, true);
        echo "\">
  <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js\"></script>
  <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js\"></script>
  <script src=\"https://ajax.aspnetcdn.com/ajax/bootstrap/4.3.1/bootstrap.min.js\"></script>
  <script src=\"https://kit.fontawesome.com/b0240f81b7.js\" crossorigin=\"anonymous\"></script>
  <link href=\"https://fonts.googleapis.com/css?family=Orbitron|Tomorrow&display=swap\" rel=\"stylesheet\">
  <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
</head>

<body>
  <!-- navbar -->
  <nav class=\"navbar navbar-expand-sm navbar-light bg-light mb-4\">
    <a class=\"navbar-brand\" href=\"/\"><i class=\"fas fa-theater-masks\"></i> Big E</a>
    <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarSupportedContent\" aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
      <span class=\"navbar-toggler-icon\"></span>
    </button>
    <div class=\"collapse navbar-collapse\" id=\"navbarSupportedContent\">
      <!-- mr-auto: maximum margin right to make next sibling \"float\" right -->
      <ul class=\"navbar-nav mr-auto\">
        <li class=\"nav-item dropdown\">
          <a class=\"nav-link dropdown-toggle\" href=\"/\" id=\"navbarDropdown\" role=\"button\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
            Events
          </a>
          <div class=\"dropdown-menu\" aria-labelledby=\"navbarDropdown\">
            <a class=\"dropdown-item\" href=\"/\">All Events</a>
            <div class=\"dropdown-divider\"></div>
            <a class=\"dropdown-item\" href=\"/major%20events\">Major Events</a>
            <a class=\"dropdown-item\" href=\"/concerts\">Concerts</a>
            <a class=\"dropdown-item\" href=\"/theater\">Theater</a>
            <a class=\"dropdown-item\" href=\"/exhibitions\">Exhibitions</a>
          </div>
        </li>
        <li class=\"nav-item\">
          <a class=\"nav-link\" href=\"#\">About</a>
        </li>
      </ul>
      <form class=\"form-inline my-2 my-lg-0\">
        <a class=\"nav-link text-secondary\" href=/admin/create> <i class=\"fas fa-plus\"></i> Create </a> <a class=\"nav-link text-secondary\" href=/admin> <i class=\"fas fa-wrench\"></i> Admin</a>
      </form>
    </div>
  </nav>
  <!-- navbar-end -->
  <!-- CONTENT -->
  ";
        // line 54
        $this->displayBlock('body', $context, $blocks);
        // line 55
        echo "  <!-- CONTENT-END -->
  <!-- footer -->
  <footer class=\"mt-4\">
    <div class=\"bottomnav p-4\">
      <a href=\"/\">Home</a> |
      <a href=\"/about\">About</a>
    </div>
    <h5 class=\"pt-2 pb-5 text-center\">&#0169; David Riediger / CodeFactory</h5>
  </footer>
  <!-- footer-end -->
  <!-- scroll button -->
  <div id='scrollBtn'><span>^</span></div>
  <script src=\"";
        // line 67
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/scrollbtn.js"), "html", null, true);
        echo "\"></script>
</body>

</html>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 8
    public function block_title($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 54
    public function block_body($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  150 => 54,  132 => 8,  118 => 67,  104 => 55,  102 => 54,  62 => 17,  53 => 11,  47 => 8,  38 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html lang=\"en\">

<head>
  <meta charset=\"utf-8\">
  <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
  <title>{% block title %}Welcome!{% endblock %}</title>
  <!-- Bootstrap core CSS -->
  <link rel=\"stylesheet\" href=\"https://ajax.aspnetcdn.com/ajax/bootstrap/4.3.1/css/bootstrap.min.css\">
  <link rel=\"stylesheet\" href=\"{{ asset('css/styles.css') }}\">
  <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js\"></script>
  <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js\"></script>
  <script src=\"https://ajax.aspnetcdn.com/ajax/bootstrap/4.3.1/bootstrap.min.js\"></script>
  <script src=\"https://kit.fontawesome.com/b0240f81b7.js\" crossorigin=\"anonymous\"></script>
  <link href=\"https://fonts.googleapis.com/css?family=Orbitron|Tomorrow&display=swap\" rel=\"stylesheet\">
  <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
</head>

<body>
  <!-- navbar -->
  <nav class=\"navbar navbar-expand-sm navbar-light bg-light mb-4\">
    <a class=\"navbar-brand\" href=\"/\"><i class=\"fas fa-theater-masks\"></i> Big E</a>
    <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarSupportedContent\" aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
      <span class=\"navbar-toggler-icon\"></span>
    </button>
    <div class=\"collapse navbar-collapse\" id=\"navbarSupportedContent\">
      <!-- mr-auto: maximum margin right to make next sibling \"float\" right -->
      <ul class=\"navbar-nav mr-auto\">
        <li class=\"nav-item dropdown\">
          <a class=\"nav-link dropdown-toggle\" href=\"/\" id=\"navbarDropdown\" role=\"button\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
            Events
          </a>
          <div class=\"dropdown-menu\" aria-labelledby=\"navbarDropdown\">
            <a class=\"dropdown-item\" href=\"/\">All Events</a>
            <div class=\"dropdown-divider\"></div>
            <a class=\"dropdown-item\" href=\"/major%20events\">Major Events</a>
            <a class=\"dropdown-item\" href=\"/concerts\">Concerts</a>
            <a class=\"dropdown-item\" href=\"/theater\">Theater</a>
            <a class=\"dropdown-item\" href=\"/exhibitions\">Exhibitions</a>
          </div>
        </li>
        <li class=\"nav-item\">
          <a class=\"nav-link\" href=\"#\">About</a>
        </li>
      </ul>
      <form class=\"form-inline my-2 my-lg-0\">
        <a class=\"nav-link text-secondary\" href=/admin/create> <i class=\"fas fa-plus\"></i> Create </a> <a class=\"nav-link text-secondary\" href=/admin> <i class=\"fas fa-wrench\"></i> Admin</a>
      </form>
    </div>
  </nav>
  <!-- navbar-end -->
  <!-- CONTENT -->
  {% block body %}{% endblock %}
  <!-- CONTENT-END -->
  <!-- footer -->
  <footer class=\"mt-4\">
    <div class=\"bottomnav p-4\">
      <a href=\"/\">Home</a> |
      <a href=\"/about\">About</a>
    </div>
    <h5 class=\"pt-2 pb-5 text-center\">&#0169; David Riediger / CodeFactory</h5>
  </footer>
  <!-- footer-end -->
  <!-- scroll button -->
  <div id='scrollBtn'><span>^</span></div>
  <script src=\"{{ asset('js/scrollbtn.js') }}\"></script>
</body>

</html>", "base.html.twig", "C:\\xampp\\htdocs\\CodeFactory\\CodeReview 13 - Symfony\\CR13\\app\\Resources\\views\\base.html.twig");
    }
}
