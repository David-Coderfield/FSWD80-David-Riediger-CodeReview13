<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* public/index.html.twig */
class __TwigTemplate_d36a4666a692ee063dd7201b3ba4b811578f6b2d33a11d88deb9488ee35b4b71 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "public/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "public/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "public/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_body($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "
<div class=\"container\">
  <h3 class=\"text-center my-3\"> ";
        // line 5
        echo twig_escape_filter($this->env, ($context["categoryMsg"] ?? $this->getContext($context, "categoryMsg")), "html", null, true);
        echo " </h3>
  <div class=\"row\">
    ";
        // line 7
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["events"] ?? $this->getContext($context, "events")));
        foreach ($context['_seq'] as $context["_key"] => $context["event"]) {
            // line 8
            echo "    <div class='col-12 col-md-6 col-lg-4 col-xl-3 my-4'>
      <div class='card mx-auto h-100' style='width:95%;'>
        <img src='";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "image", []), "html", null, true);
            echo "' class='card-img-top' alt='image'>
        <div class='card-body'>
          <h5 class='card-title vienna'>";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "title", []), "html", null, true);
            echo "</h5>
          <h6 class=''>";
            // line 13
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["event"], "dueDate", []), "F j, Y, g:i a"), "html", null, true);
            echo "</h6>
        </div>
        <ul class='list-group list-group-flush'>
          <li class='list-group-item'><h6 class=''>";
            // line 16
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "location", []), "html", null, true);
            echo "</h6>
          <p>";
            // line 17
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "address", []), "html", null, true);
            echo "</p></li>
          <li class='list-group-item'><span class=\"italic\">";
            // line 18
            echo twig_escape_filter($this->env, twig_slice($this->env, strip_tags($this->getAttribute($context["event"], "description", [])), 0, 101), "html", null, true);
            echo "... </span><a href=\"/details/";
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "id", []), "html", null, true);
            echo "\">read more</a></li>
        </ul>
        <div class='card-body'>
          <a href='";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "www", []), "html", null, true);
            echo "' class='card-link'><i class='fas fa-globe'></i> Visit</a> | Tickets available: ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["event"], "capacity", []), "html", null, true);
            echo "
        </div>
      </div>
    </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['event'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 26
        echo "  </div>
</div>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "public/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  121 => 26,  108 => 21,  100 => 18,  96 => 17,  92 => 16,  86 => 13,  82 => 12,  77 => 10,  73 => 8,  69 => 7,  64 => 5,  60 => 3,  51 => 2,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}
{% block body %}

<div class=\"container\">
  <h3 class=\"text-center my-3\"> {{ categoryMsg }} </h3>
  <div class=\"row\">
    {% for event in events %}
    <div class='col-12 col-md-6 col-lg-4 col-xl-3 my-4'>
      <div class='card mx-auto h-100' style='width:95%;'>
        <img src='{{ event.image }}' class='card-img-top' alt='image'>
        <div class='card-body'>
          <h5 class='card-title vienna'>{{ event.title }}</h5>
          <h6 class=''>{{ event.dueDate|date('F j, Y, g:i a') }}</h6>
        </div>
        <ul class='list-group list-group-flush'>
          <li class='list-group-item'><h6 class=''>{{ event.location }}</h6>
          <p>{{ event.address}}</p></li>
          <li class='list-group-item'><span class=\"italic\">{{ event.description|striptags|slice(0, 101)}}... </span><a href=\"/details/{{ event.id }}\">read more</a></li>
        </ul>
        <div class='card-body'>
          <a href='{{ event.www }}' class='card-link'><i class='fas fa-globe'></i> Visit</a> | Tickets available: {{ event.capacity }}
        </div>
      </div>
    </div>
    {% endfor %}
  </div>
</div>

{% endblock %}", "public/index.html.twig", "C:\\xampp\\htdocs\\CodeFactory\\CodeReview 13 - Symfony\\CR13\\app\\Resources\\views\\public\\index.html.twig");
    }
}
