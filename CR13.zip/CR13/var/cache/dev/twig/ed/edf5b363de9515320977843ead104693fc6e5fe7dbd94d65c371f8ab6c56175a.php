<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* admin/details.html.twig */
class __TwigTemplate_cb17a73d02d49333a81688b0d5dffc596384cb63fb2480d754824cc9fb072cef extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "admin/details.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "admin/details.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "admin/details.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_body($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "<div class=\"container detailpage\">
  <div class=\"description-container\">
    <img src=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "image", []), "html", null, true);
        echo "\" alt=\"eventimage\" class=\"float-right bigimage m-1\">
    <h3 class=\"page-header vienna pb-3\">";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "title", []), "html", null, true);
        echo "</h3>
    <h6>";
        // line 7
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "dueDate", []), "F j, Y, g:i a"), "html", null, true);
        echo "</h6>
    <p>(";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "eventType", []), "html", null, true);
        echo ")</p>
    <p>";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "description", []), "html", null, true);
        echo "</p>
  </div>
  <hr>
  <h5 class=\"vienna\">";
        // line 12
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "location", []), "html", null, true);
        echo "</h5>
  <p> 
  \t";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "address", []), "html", null, true);
        echo "
  \t<br><small>Tickets left: ";
        // line 15
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "capacity", []), "html", null, true);
        echo "</small>
  </p>
  
  <ul>
    <li><i class=\"fas fa-phone pr-1\"></i> ";
        // line 19
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "phone", []), "html", null, true);
        echo "</li>
    <li><i class=\"far fa-envelope pr-2\"></i> <a href=\"mailto:";
        // line 20
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "email", []), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "email", []), "html", null, true);
        echo "</a></li>
    <li><i class=\"fas fa-globe pr-2\"></i> <a href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "www", []), "html", null, true);
        echo "\">visit site</a></li>
  </ul>
  <a href=\"/\"><i class=\"fas fa-arrow-left\"></i> Back to Events</a>
  <br><a href=\"/admin\"><i class=\"fas fa-arrow-left\"></i> Back to Adminpanel</a>
  <hr>
  <a href=\"/admin/edit/";
        // line 26
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "id", []), "html", null, true);
        echo "\" class=\"btn btn btn-primary\">Edit</a>
  <a href=\"/admin/delete/";
        // line 27
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "id", []), "html", null, true);
        echo "\" class=\"btn btn btn-danger\">Delete</a>
</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "admin/details.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  124 => 27,  120 => 26,  112 => 21,  106 => 20,  102 => 19,  95 => 15,  91 => 14,  86 => 12,  80 => 9,  76 => 8,  72 => 7,  68 => 6,  64 => 5,  60 => 3,  51 => 2,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}
{% block body %}
<div class=\"container detailpage\">
  <div class=\"description-container\">
    <img src=\"{{ event.image }}\" alt=\"eventimage\" class=\"float-right bigimage m-1\">
    <h3 class=\"page-header vienna pb-3\">{{event.title}}</h3>
    <h6>{{event.dueDate|date('F j, Y, g:i a')}}</h6>
    <p>({{ event.eventType }})</p>
    <p>{{event.description}}</p>
  </div>
  <hr>
  <h5 class=\"vienna\">{{event.location}}</h5>
  <p> 
  \t{{ event.address}}
  \t<br><small>Tickets left: {{ event.capacity }}</small>
  </p>
  
  <ul>
    <li><i class=\"fas fa-phone pr-1\"></i> {{ event.phone }}</li>
    <li><i class=\"far fa-envelope pr-2\"></i> <a href=\"mailto:{{ event.email }}\">{{ event.email }}</a></li>
    <li><i class=\"fas fa-globe pr-2\"></i> <a href=\"{{ event.www }}\">visit site</a></li>
  </ul>
  <a href=\"/\"><i class=\"fas fa-arrow-left\"></i> Back to Events</a>
  <br><a href=\"/admin\"><i class=\"fas fa-arrow-left\"></i> Back to Adminpanel</a>
  <hr>
  <a href=\"/admin/edit/{{event.id}}\" class=\"btn btn btn-primary\">Edit</a>
  <a href=\"/admin/delete/{{event.id}}\" class=\"btn btn btn-danger\">Delete</a>
</div>
{% endblock %}", "admin/details.html.twig", "C:\\xampp\\htdocs\\CodeFactory\\CodeReview 13 - Symfony\\CR13\\app\\Resources\\views\\admin\\details.html.twig");
    }
}
